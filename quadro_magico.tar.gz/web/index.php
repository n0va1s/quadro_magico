<?php
require __DIR__.'/../bootstrap.php';
$app->run();
