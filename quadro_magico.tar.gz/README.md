# Definição
Uma plataforma simples e transformadora para filhos e filhas cada vez mais orientados a propósito, confiantes e responsáveis.<br />
Conheça [brinquecoin.com](http://brinquecoin.com)

# Proposta
**Para** pais e mães <br />
**Que** buscam desenvolver crianças, jovens e adolescentes confiantes e responsáveis <br />
**O** site brinquecoin.com <br />
**É** como um quadro de tarefas <br />
**Diferente** daqueles quadros brancos, de cortiça ou planilhas impressas no trabalho, é mais sustentável e fácil de alterar, faz parte do mundo digital deles, possui uma metodologia de trabalho baseada em games, facilita a comunicação e permite o acompanhamento dele ou dela mesmo à distância.

# Idealizadores
Isabela Araújo
João Paulo Novais
